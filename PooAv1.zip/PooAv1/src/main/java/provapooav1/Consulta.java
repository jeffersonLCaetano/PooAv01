package provapooav1;

import java.util.Objects;

public class Consulta {

    private int id;
    private String dataConsulta;
    private String descricaoExame;
    private String historico;
    private Veterinario veterinario;

    public void status(){
        System.out.println("------------------------------------");
        System.out.println("\tId consulta: " + getId());
        System.out.println("\tNome veterinário: " + getDataConsulta());
        System.out.println("\tDescricao do exame: " + getDescricaoExame());
        System.out.println("\tHistorico: " + getHistorico());
        System.out.println("\tVeterinário: " + getVeterinario().getNome());
    }

    public Consulta() {
    }

    public Consulta(int id, String dataConsulta, String descricaoExame, String historico) {
        this.id = id;
        this.dataConsulta = dataConsulta;
        this.descricaoExame = descricaoExame;
        this.historico = historico;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataConsulta() {
        return dataConsulta;
    }

    public void setDataConsulta(String dataConsulta) {
        this.dataConsulta = dataConsulta;
    }

    public String getDescricaoExame() {
        return descricaoExame;
    }

    public void setDescricaoExame(String descricaoExame) {
        this.descricaoExame = descricaoExame;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    public Veterinario getVeterinario() {
        return veterinario;
    }

    public void setVeterinario(Veterinario veterinario) {
        this.veterinario = veterinario;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Consulta consulta = (Consulta) o;
        return id == consulta.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Consulta {" +
                "\nid= " + id +
                ", dataConsulta= '" + dataConsulta + '\'' +
                ", descricaoExame= '" + descricaoExame + '\'' +
                ", historico= '" + historico + '\'' +
                '}';
    }
}
