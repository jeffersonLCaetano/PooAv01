package provapooav1;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Veterinario {

    private int id;
    private String nome;
    private String endereco;
    private String telefone;
    private List<Consulta> listConsulta = new LinkedList<>();

    public void status(){
        System.out.println("\n--------Nome do veterinário--------");
        System.out.println("Id veterinário: " + getId());
        System.out.println("Nome veterinário: " + getNome());
        System.out.println("Endereço veterinário: " + getEndereco());
        System.out.println("Telefone veterinário: " + getTelefone());
        System.out.println("Consultas: ");
        System.out.println(getListConsulta());
    }

    public void addConsulta(Consulta consulta) {
        listConsulta.add(consulta);

    }

    public Veterinario() {
    }

    public Veterinario(int id, String nome, String endereco, String telefone) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public List<Consulta> getListConsulta() {
        return listConsulta;
    }

    public void setListConsulta(List<Consulta> listConsulta) {
        this.listConsulta = listConsulta;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Veterinario that = (Veterinario) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Veterinario{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", endereco='" + endereco + '\'' +
                ", telefone='" + telefone + '\'' +
                ", consultas=" + listConsulta +
                '}';
    }
}
