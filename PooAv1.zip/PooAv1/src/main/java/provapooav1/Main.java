package provapooav1;

public class Main {
    public static void main(String[] args) {
        Veterinario v1 = new Veterinario();
        Consulta c1 = new Consulta();
        Consulta c2 = new Consulta();

        v1.setId(123);
        v1.setNome("João");
        v1.setEndereco("Rua Lero Lero, 12");
        v1.setTelefone("984.028.744");

        c1.setId(111);
        c1.setDataConsulta("06/10/2023");
        c1.setDescricaoExame("Clinico");
        c1.setHistorico("Tô fudido");
        c1.setVeterinario(v1);

        c2.setId(222);
        c2.setDataConsulta("08/11/2023");
        c2.setDescricaoExame("Clinico Geral");
        c2.setHistorico("Tô fudido mais fudido ainda");
        c2.setVeterinario(v1);

        v1.addConsulta(c1);
        v1.addConsulta(c2);

        //String u = v1.toString();
        //System.out.println(v1.toString());

        v1.status ();
        c1.status();
        c2.status();

    }
}
